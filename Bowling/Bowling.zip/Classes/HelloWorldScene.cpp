#include "HelloWorldScene.h"
#include "cocostudio/CocoStudio.h"
#include "CameraControl.h"
#include "Camera3D.h"

#include "physics3d/PhysicsMesh3D.h"
USING_NS_CC;

using namespace cocostudio::timeline;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}
static DrawNode* drawNode;
// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    do
	{
		CC_BREAK_IF(!Layer::init());

		CC_BREAK_IF(!initCamera());
		CC_BREAK_IF(!initPhysics3D());
		CC_BREAK_IF(!initListener());

		auto rootNode = CSLoader::createNode("MainScene.csb");
		addChild(rootNode);
		auto closeItem = static_cast<ui::Button*>(rootNode->getChildByName("Button_1"));
		closeItem->addClickEventListener(CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
		
		_labelInfo = static_cast<ui::Text*>(rootNode->getChildByName("lbl_body_info"));
		
		this->scheduleUpdate();
		drawNode = DrawNode::create();
		this->addChild(drawNode);


		return true;
	} while (0);

    return false;
}

bool HelloWorld::initPhysics3D()
{
	_world = PhysicsWorld3D::createWithDebug(this);	// ����3d��������
	if (_world == nullptr)
	{
		return false;
	}
	
	this->addSomeBodies();	// to test bodies

	// ����2������ɼ�
	this->setCameraMask(2);
	return true;
}

bool HelloWorld::initCamera()
{
	auto size = Director::getInstance()->getVisibleSize();
	_camera = Camera3D::create(60, size.width / size.height, 0.1f, 1000);
	if (_camera == nullptr)
	{
		return false;
	}
	_camera->setCameraFlag(CameraFlag::USER1); // ����Ϊ2
	this->addChild(_camera);
	_camera->setPosition3D(Vec3(0, 2, 0));	// �����λ��
	_camera->lookAt(Vec3::ZERO, Vec3(0, 1, 0)); // �����target
	_camera->setMoveSpeed(5.f);

	auto cameraCtrl = CameraControl::create();
	cameraCtrl->setCamera(_camera);
	
	this->addChild(cameraCtrl);

	return true;
}

bool HelloWorld::initListener()
{
	_touchListener = EventListenerTouchOneByOne::create();
	if (_touchListener == nullptr)
	{
		return false;
	}

	_touchListener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
	_touchListener->onTouchMoved = CC_CALLBACK_2(HelloWorld::onTouchMoved, this);
	_touchListener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);

	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(_touchListener, this);
	return true;
}

void HelloWorld::addSomeBodies()
{
	_phyMesh3D = PhysicsMesh3D::constuct("heightmap.raw");
	_world->addTriangleMeshShape(_phyMesh3D, btVector3(0, 0, 0));

	// ����planeģ��
	auto spPlane = Sprite3D::create("model/heightmap.c3b"); 
	this->addChild(spPlane);
	spPlane->setPosition3D(Vec3(0, 0, 0));
	spPlane->setRotation3D(Vec3(0, 180, 0));

	//// add a plane ��������,λ��(0,0,0), 0.5��Ħ��,0.5�ĵ���
	//_world->addPlane(btVector3(0, 1, 0), btVector3(0, 0, 0), PHYSICS_MATERIAL3D_PLANE);
	
	btRigidBody* body = nullptr;

	// read raw
	_heightMapData = FileUtils::getInstance()->getDataFromFile("map.raw");
	
	// add height field
	
	//extern char heightMap[];
	////float *mapData = (float*)heightMap;
	//short *mapData = (short*)heightMap;
	//unsigned char uData = 0;
	//for (int i=0; i<128; ++i)
	//{
	//	for (int j=0; j<128; ++j)
	//	{
	//		mapData[i*128+j] = j % 2;
	//		if (uData < _heightMapData.getBytes()[i*128+j])
	//		{
	//			uData = _heightMapData.getBytes()[i*128+j];
	//		}
	//	}
	//}
	//HeightfieldInfo info(128, 128, _heightMapData.getBytes(), PHY_UCHAR, 1.6f / uData, -1.f, 1.f, btVector3(25.f / uData, 1.f, 25.f / uData));
	////HeightfieldInfo info(128, 128, mapData, PHY_SHORT, 1.f, -2.f, 1.f, btVector3(1.f, 1.f, 1.f));
	//_world->addHeightfieldTerrain(info, btVector3(-0.25f, 0.f, 0.42f));

	// �������ģ��
	_spBox = Sprite3D::create("model/box.c3b");
	this->addChild(_spBox);
	_spBox->setPosition3D(Vec3(0, 5, 0));

	// add a box
	_box = _world->addBox(btVector3(1.f, 1.f, 1.f), btVector3(6, 5.f, 0));
	_box->setUserPointer(_spBox);

	// add Sphere
	body = _world->addSphere(0.1f, btVector3(4.f, 10.f, 0.f));
	_rigidBodies.push_back(body);
	// add Capsule
	body = _world->addCapsule(1.f, 1.f, btVector3(-10.f, 10.f, 0.f));
	_rigidBodies.push_back(body);
	// add Cylinder
	body = _world->addCylinder(btVector3(2.f, 2.0f, 2.f), btVector3(-6.f, 10.f, 0.f));
	_rigidBodies.push_back(body);
	// add Cone
	body = _world->addCone(1.f, 2.f, btVector3(-2.f, 10.f, 0.f));
	_rigidBodies.push_back(body);
	// add multi spheres
	btVector3 positions[] = {
		btVector3(-1.f, 1.f, 0.f),
		btVector3(1.f, 1.f, 0.f),
		btVector3(0.f, -1.f, 0.f)
	};

	btScalar radi[] = {
		1.f, 0.5f, 1.f
	};

	body = _world->addMultiSphere(radi, positions, 3, btVector3(4.f, 3.f, 0.f));
	_rigidBodies.push_back(body);
}

void HelloWorld::onExit()
{
	Layer::onExit();

	_world->destroy();		// ������������
	_world = nullptr;

	_rigidBodies.clear();
	_phyMesh3D->destroy();

	Director::getInstance()->getEventDispatcher()->removeEventListener(_touchListener);
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
    return;
#endif

    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

bool HelloWorld::onTouchBegan(Touch *touch, Event *unused_event)
{
	auto cameraPos = _camera->getPosition3D();
	for (auto body : _rigidBodies)
	{
		body->setActivationState(ACTIVE_TAG);
		body->applyCentralImpulse(btVector3(0, 5.f, 0));
	}
	return true;
}

void HelloWorld::onTouchMoved(Touch *touch, Event *unused_event)
{

}

void HelloWorld::onTouchEnded(Touch *touch, Event *unused_event)
{

}

void HelloWorld::draw(Renderer *renderer, const Mat4 &transform, uint32_t flags)
{
	_world->debugDraw();
	Layer::draw(renderer, transform, flags);
}

void HelloWorld::update(float delta)
{
	static float m[16];
	_world->update(delta);
	auto trans = _box->getWorldTransform();		// ��ȡbox�ı任����
	trans.getOpenGLMatrix(m);
	_spBox->setNodeToParentTransform(Mat4(m));	// ����boxģ�͵ı任���󣬵���getPosition3D����õ���ȷλ�ã�����Ժ�����

	auto camPos = _camera->getPosition3D();
	auto camInfo = __String::createWithFormat("%.2f,%.2f,%.2f", camPos.x, camPos.y, camPos.z);
	_labelInfo->setString(camInfo->getCString());
}