#include "bullet/btBulletDynamicsCommon.h"


struct Physics3DMaterial
{
	btScalar friction;
	btScalar rollingFriction;
	btScalar restitution;
	btScalar mass;
		
	Physics3DMaterial() :
		friction(0.0f),
		rollingFriction(0.f),
		restitution(0.f),
		mass(0.f)
	{}

	Physics3DMaterial(btScalar aMass, btScalar aFriction, btScalar aRestitution, btScalar aRollingFriction) :
		friction(aFriction),
		rollingFriction(aRollingFriction),
		restitution(aRestitution),
		mass(aMass)
	{}
};

const Physics3DMaterial PHYSICS3D_MATERIAL_DEFAULT(1.f, 0.5f, 0.5f, 0.0f);

class PhysicsWorld3D
{
public:
	~PhysicsWorld3D();

	static PhysicsWorld3D* create(const btVector3& gravity = btVector3(0, -10, 0));
	bool initWorld(const btVector3& gravity);
	void destroy();

	btRigidBody* addPlane(const btVector3& normal, const btVector3& position, const Physics3DMaterial& material = PHYSICS3D_MATERIAL_DEFAULT);
	btRigidBody* addSphere(btScalar radius, const btVector3& position, const Physics3DMaterial& material = PHYSICS3D_MATERIAL_DEFAULT);
	btRigidBody* addBox(const btVector3& size, const btVector3& position, const Physics3DMaterial& material = PHYSICS3D_MATERIAL_DEFAULT);

	void update(float dt);

private:
	void clear();

private:
	btRigidBody* getBody(btCollisionShape* colShape, const btVector3& position, const Physics3DMaterial& material);

private:
	btDiscreteDynamicsWorld* _world;
	btDefaultCollisionConfiguration* _collisionConfiguration;
	btCollisionDispatcher* _dispatcher;
	btBroadphaseInterface* _overlappingPairCache;
	btSequentialImpulseConstraintSolver* _solver;

};
